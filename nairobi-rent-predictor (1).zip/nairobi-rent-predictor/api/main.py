"""FastAPI service wrapping the trained rent model.

    uvicorn api.main:app --host 0.0.0.0 --port 8000
    Interactive docs: http://localhost:8000/docs
"""
import json
import sys
from enum import Enum
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from rentml import config as C  # noqa: E402
from rentml.predict import load_artifact, predict_rent  # noqa: E402

SubCounty = Enum("SubCounty", {v: v for v in C.SUBCOUNTY_VALUES}, type=str)
Structure = Enum("Structure", {v: v for v in C.STRUCTURE_VALUES}, type=str)
Flag = Optional[int]


class Listing(BaseModel):
    """One rental unit. Only location, structure and bedrooms are required;
    anything left out is treated as unknown and imputed by the model."""
    model_config = ConfigDict(extra="forbid", json_schema_extra={"example": {
        "sub_county": "Westlands", "structure": "apartment", "bedrooms": 2,
        "bathrooms": 2, "floor_area_sqm": 95, "parking": 1, "elevator": 1,
        "backup_generator": 1, "fixed_internet": 1}})

    sub_county: SubCounty
    structure: Structure
    bedrooms: int = Field(ge=0, le=4, description="0 for single room / bedsitter; 4 means 4 or more")
    bathrooms: Optional[int] = Field(None, ge=0, le=8)
    floor_area_sqm: Optional[float] = Field(None, ge=C.AREA_MIN_SQM, le=C.AREA_MAX_SQM)
    building_age: Optional[float] = Field(None, ge=0, le=120, description="years since completion")
    similar_units: Optional[int] = Field(None, ge=0, le=300, description="similar units on offer")
    advert_year: Optional[int] = Field(None, ge=2000, le=C.SURVEY_YEAR + 1)
    parking: Flag = Field(None, ge=0, le=1)
    dsq: Flag = Field(None, ge=0, le=1)
    service_charge_included: Flag = Field(None, ge=0, le=1)
    cctv: Flag = Field(None, ge=0, le=1)
    elevator: Flag = Field(None, ge=0, le=1)
    garden_play_area: Flag = Field(None, ge=0, le=1)
    swimming_pool: Flag = Field(None, ge=0, le=1)
    backup_generator: Flag = Field(None, ge=0, le=1)
    fixed_internet: Flag = Field(None, ge=0, le=1)
    solar_water_heating: Flag = Field(None, ge=0, le=1)
    solar_lighting: Flag = Field(None, ge=0, le=1)
    gym: Flag = Field(None, ge=0, le=1)
    fire_safety: Flag = Field(None, ge=0, le=1)
    solar_security_lighting: Flag = Field(None, ge=0, le=1)
    access_ramp: Flag = Field(None, ge=0, le=1)


class Prediction(BaseModel):
    predicted_rent_ksh: float
    likely_range_ksh: list[float] = Field(description="empirical 80% band from cross-validation")


class BatchRequest(BaseModel):
    listings: list[Listing] = Field(min_length=1, max_length=500)


app = FastAPI(
    title="Nairobi Rent Predictor",
    version="1.0.0",
    description="Predicts advertised monthly rent (KSh) for residential units in Nairobi City "
                "County from location, size, amenities and design. DSA 8401 capstone.",
)


def _artifact():
    try:
        return load_artifact()
    except FileNotFoundError:
        raise HTTPException(503, "Model artifact not found. Run `python run_pipeline.py` first.")


def _records(listings: list[Listing]) -> list[dict]:
    return [l.model_dump(mode="json") for l in listings]


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": C.MODEL_PATH.exists()}


@app.get("/model-info")
def model_info():
    if not C.METADATA_PATH.exists():
        raise HTTPException(503, "Model metadata not found.")
    return json.loads(C.METADATA_PATH.read_text())


@app.post("/predict", response_model=Prediction)
def predict(listing: Listing):
    return predict_rent(_records([listing]), _artifact())[0]


@app.post("/predict/batch", response_model=list[Prediction])
def predict_batch(req: BatchRequest):
    return predict_rent(_records(req.listings), _artifact())
