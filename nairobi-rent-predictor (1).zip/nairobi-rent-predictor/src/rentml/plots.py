"""Report figures (static PNGs for the README / report)."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter

from . import config as C

BLUE, INK, MUTED, GRID, SURFACE = "#2a78d6", "#0b0b0b", "#52514e", "#e6e5e1", "#fcfcfb"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": GRID, "axes.labelcolor": MUTED, "text.color": INK,
    "xtick.color": MUTED, "ytick.color": MUTED, "font.size": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlelocation": "left",
})


def _save(fig, name):
    C.FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(C.FIG_DIR / name, dpi=160)
    plt.close(fig)


def _hbar(ax, labels, values, fmt):
    y = np.arange(len(labels))[::-1]
    ax.barh(y, values, height=0.6, color=BLUE)
    ax.set_yticks(y, labels)
    ax.tick_params(length=0)
    ax.spines["left"].set_visible(False)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for yi, v in zip(y, values):
        ax.text(v, yi, "  " + fmt(v), va="center", ha="left", color=INK)
    ax.set_xlim(0, max(values) * 1.15)


def model_comparison(summary):
    s = summary.sort_values("MdAPE_pct")
    fig, ax = plt.subplots(figsize=(8, 3.6))
    _hbar(ax, s.index, s["MdAPE_pct"], lambda v: f"{v:.1f}%")
    ax.set_title("Typical error on unseen firms, by model")
    ax.set_xlabel("Median absolute percentage error, nested firm-grouped CV (lower is better)")
    _save(fig, "model_comparison.png")


def predicted_vs_actual(y, pred, name):
    fig, ax = plt.subplots(figsize=(5.6, 5.4))
    ax.scatter(y, pred, s=22, color=BLUE, alpha=0.55, edgecolor=SURFACE, linewidth=0.6)
    lim = [min(y.min(), pred.min()) * 0.8, max(y.max(), pred.max()) * 1.25]
    ax.plot(lim, lim, color=MUTED, linewidth=1, linestyle="--")
    ax.set(xscale="log", yscale="log", xlim=lim, ylim=lim)
    k = FuncFormatter(lambda v, _: f"{v / 1000:,.0f}k")
    ax.xaxis.set_major_formatter(k)
    ax.yaxis.set_major_formatter(k)
    ax.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.set_title(f"Out-of-fold predictions, {name}")
    ax.set_xlabel("Advertised monthly rent, KSh (log scale)")
    ax.set_ylabel("Predicted rent, KSh (log scale)")
    ax.text(lim[1] * 0.9, lim[1] * 0.75, "perfect prediction", color=MUTED, ha="right", va="top",
            fontsize=9)
    _save(fig, "predicted_vs_actual.png")


def importance(imp):
    fig, ax = plt.subplots(figsize=(8, 3.2))
    _hbar(ax, imp.index, imp["error_increase_pct"].clip(lower=0), lambda v: f"+{v:.0f}%")
    ax.set_title("What the model relies on, by proposal objective")
    ax.set_xlabel("Increase in out-of-sample error when the group is shuffled")
    _save(fig, "feature_group_importance.png")


def leakage(audit):
    labels = list(audit)
    fig, ax = plt.subplots(figsize=(8, 2.6))
    _hbar(ax, labels, [audit[k]["MdAPE_pct"] for k in labels], lambda v: f"{v:.1f}%")
    ax.set_title("Same model, three evaluation protocols")
    ax.set_xlabel("Median absolute percentage error")
    _save(fig, "leakage_audit.png")
