"""Stage 3: preprocessing and candidate model definitions.

All models are scikit-learn Pipelines fitted on log(rent), so preprocessing is
learned inside each cross-validation fold and nothing leaks from test folds.
"""
from __future__ import annotations

import numpy as np
from lightgbm import LGBMRegressor
from scipy.stats import loguniform, randint, uniform
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.svm import SVR
from xgboost import XGBRegressor

from . import config as C


def make_preprocessor(scale: bool) -> ColumnTransformer:
    num_steps = [("impute", SimpleImputer(strategy="median", add_indicator=True))]
    if scale:
        num_steps.append(("scale", StandardScaler()))
    return ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), C.CATEGORICAL),
        ("num", Pipeline(num_steps), C.NUMERIC),
        ("bin", SimpleImputer(strategy="most_frequent"), C.BINARY),
    ])


class GroupMedianBaseline(BaseEstimator, RegressorMixin):
    """Naive benchmark: median log-rent of the (sub-county, bedrooms) cell,
    falling back to the bedroom median and then the overall median."""

    def fit(self, X, y):
        d = X[["sub_county", "bedrooms"]].copy()
        d["y"] = np.asarray(y)
        self.cell_ = d.groupby(["sub_county", "bedrooms"])["y"].median().to_dict()
        self.bed_ = d.groupby("bedrooms")["y"].median().to_dict()
        self.all_ = float(d["y"].median())
        return self

    def predict(self, X):
        out = []
        for sc, b in zip(X["sub_county"], X["bedrooms"]):
            out.append(self.cell_.get((sc, b), self.bed_.get(b, self.all_)))
        return np.asarray(out)


def candidates() -> dict:
    """name -> (estimator, param_distributions or None)."""
    rs = C.RANDOM_STATE
    return {
        "Median by sub-county x bedrooms": (GroupMedianBaseline(), None),
        "Ridge regression": (
            Pipeline([("prep", make_preprocessor(True)), ("model", Ridge())]),
            {"model__alpha": loguniform(1e-2, 1e2)},
        ),
        "Random forest": (
            Pipeline([("prep", make_preprocessor(False)),
                      ("model", RandomForestRegressor(n_estimators=300, random_state=rs, n_jobs=1))]),
            {"model__max_depth": [None, 6, 10, 14],
             "model__min_samples_leaf": randint(1, 8),
             "model__max_features": uniform(0.3, 0.6)},
        ),
        "SVM (RBF)": (
            Pipeline([("prep", make_preprocessor(True)), ("model", SVR(kernel="rbf"))]),
            {"model__C": loguniform(0.3, 100),
             "model__gamma": loguniform(1e-3, 0.3),
             "model__epsilon": loguniform(0.01, 0.5)},
        ),
        "XGBoost": (
            Pipeline([("prep", make_preprocessor(False)),
                      ("model", XGBRegressor(random_state=rs, n_jobs=1, tree_method="hist"))]),
            {"model__n_estimators": randint(150, 600),
             "model__learning_rate": loguniform(0.01, 0.2),
             "model__max_depth": randint(2, 7),
             "model__subsample": uniform(0.6, 0.4),
             "model__colsample_bytree": uniform(0.5, 0.5),
             "model__min_child_weight": randint(1, 8),
             "model__reg_lambda": loguniform(0.1, 10)},
        ),
        "LightGBM": (
            Pipeline([("prep", make_preprocessor(False)),
                      ("model", LGBMRegressor(random_state=rs, n_jobs=1, verbose=-1))]),
            {"model__n_estimators": randint(150, 600),
             "model__learning_rate": loguniform(0.01, 0.2),
             "model__num_leaves": randint(4, 32),
             "model__min_child_samples": randint(5, 30),
             "model__subsample": uniform(0.6, 0.4),
             "model__subsample_freq": [1],
             "model__colsample_bytree": uniform(0.5, 0.5),
             "model__reg_lambda": loguniform(0.1, 10)},
        ),
    }
