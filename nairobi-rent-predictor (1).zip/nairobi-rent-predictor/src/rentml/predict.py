"""Stage 5: prediction helper shared by the CLI and the API."""
from __future__ import annotations

from functools import lru_cache

import joblib
import numpy as np
import pandas as pd

from . import config as C


@lru_cache(maxsize=1)
def load_artifact(path: str = str(C.MODEL_PATH)) -> dict:
    return joblib.load(path)


def predict_rent(records: list[dict], artifact: dict | None = None) -> list[dict]:
    """records: list of feature dicts; missing keys are treated as unknown."""
    art = artifact or load_artifact()
    X = pd.DataFrame(records).reindex(columns=art["features"])
    for col in C.NUMERIC + C.BINARY:
        X[col] = pd.to_numeric(X[col], errors="coerce")
    for col in C.CATEGORICAL:
        X[col] = X[col].astype(object).where(X[col].notna(), np.nan)
    log_pred = art["pipeline"].predict(X)
    return [{
        "predicted_rent_ksh": float(round(np.exp(p), -2)),
        "likely_range_ksh": [float(round(np.exp(p + art["log_resid_q10"]), -2)),
                             float(round(np.exp(p + art["log_resid_q90"]), -2))],
    } for p in log_pred]
