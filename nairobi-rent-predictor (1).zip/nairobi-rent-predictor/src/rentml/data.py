"""Stage 1-2: ingestion and cleaning.

`build_dataset()` turns the raw KNBS Stata file into a tidy modelling table and
returns a data-quality log recording how many rows each rule removed, so the
preprocessing is documented by the code that performs it.
"""
from __future__ import annotations

import json
import re

import numpy as np
import pandas as pd

from . import config as C


# --------------------------------------------------------------------------
# KNBS real-estate survey (primary source)
# --------------------------------------------------------------------------
def load_knbs_rentals(path=C.RAW_KNBS) -> pd.DataFrame:
    """Read the residential-rental roster (section RB) of the KNBS survey.

    The file is a wide export with one row per roster line across several
    questionnaire sections; rows that belong to the rental roster are the ones
    with a non-missing `rbid`.
    """
    cols = (["interview__id", "rbid", "rb2", "rb3", "rb4", "rb5", "rb6", "rb8", "rb9",
             "rb12a", "rb12b", "rb13", "rb14", "rb16", "rb17"] + list(C.AMENITIES))
    df = pd.read_stata(path, columns=cols, convert_categoricals=False)
    return df[df["rbid"].notna()].reset_index(drop=True)


def clean_knbs(raw: pd.DataFrame, deduplicate: bool = True) -> tuple[pd.DataFrame, dict]:
    log: dict[str, int] = {"rental_roster_rows": int(len(raw))}

    df = raw[raw["rb8"] == C.NAIROBI_COUNTY_CODE].copy()
    log["nairobi_rows"] = int(len(df))

    # ---- target: advertised monthly rent --------------------------------
    df[C.TARGET] = df["rb13"]
    ok = df[C.TARGET].between(C.RENT_MIN, C.RENT_MAX)
    log["dropped_rent_missing_or_implausible"] = int((~ok).sum())
    df = df[ok]

    # ---- property type -> structure + bedrooms --------------------------
    ptype = df["rb2"].map(C.PROPERTY_TYPE)
    known = ptype.notna()
    log["dropped_unknown_property_type"] = int((~known).sum())
    df, ptype = df[known], ptype[known]
    df["structure"] = ptype.str[0]
    df["bedrooms"] = ptype.str[1].astype(float)

    # ---- location -------------------------------------------------------
    df["sub_county"] = df["rb9"].map(C.NAIROBI_SUBCOUNTY)
    known = df["sub_county"].notna()
    log["dropped_sub_county_missing"] = int((~known).sum())
    df = df[known]

    # ---- size -----------------------------------------------------------
    df["bathrooms"] = df["rb3"].clip(upper=8)
    area = df["rb12b"].where(~df["rb12b"].isin(C.AREA_PLACEHOLDER))
    area = np.where(df["rb12a"] == 1, area * C.SQFT_TO_SQM, area)  # 1 = sq ft, 2 = sq m
    area = pd.Series(area, index=df.index)
    area = area.where(area.between(C.AREA_MIN_SQM, C.AREA_MAX_SQM))
    log["floor_area_set_missing"] = int(area.isna().sum())
    df["floor_area_sqm"] = area

    # ---- design / age ---------------------------------------------------
    built = df["rb16"].where(df["rb16"].between(1900, C.SURVEY_YEAR))
    df["building_age"] = C.SURVEY_YEAR - built
    df["dsq"] = df["rb5"]
    df["parking"] = df["rb4"]

    # ---- amenities ------------------------------------------------------
    for src, name in C.AMENITIES.items():
        df[name] = df[src]

    # ---- listing terms --------------------------------------------------
    df["similar_units"] = df["rb6"].clip(upper=300)
    df["advert_year"] = df["rb14"].where(df["rb14"].between(2000, C.SURVEY_YEAR + 1))
    df["service_charge_included"] = df["rb17"]

    df[C.GROUP] = df["interview__id"]
    out = df[[C.GROUP] + C.FEATURES + [C.TARGET]]

    # ---- exact duplicates -----------------------------------------------
    # Firms report blocks of identical units as repeated roster lines. Keeping
    # them would put the same observation in both train and test folds.
    # (`deduplicate=False` exists only so the leakage audit can show the effect.)
    before = len(out)
    out = (out.drop_duplicates() if deduplicate else out).reset_index(drop=True)
    log["dropped_exact_duplicates"] = int(before - len(out))
    log["final_rows"] = int(len(out))
    log["final_firms"] = int(out[C.GROUP].nunique())
    return out, log


# --------------------------------------------------------------------------
# Kaggle apartment listings (secondary source, external check only)
# --------------------------------------------------------------------------
def load_kaggle(path=C.RAW_KAGGLE) -> tuple[pd.DataFrame, dict]:
    raw = pd.read_csv(path, index_col=0)
    log = {"raw_rows": int(len(raw))}
    df = raw.drop_duplicates().copy()
    log["unique_listings"] = int(len(df))

    df = df[df["rate"] == "Per Month"]
    df[C.TARGET] = df["price"].astype(str).str.replace(r"\s+", "", regex=True).astype(float)
    df["neighbourhood"] = df["title"].str.extract(r"to rent in (.+)$")[0].str.strip()
    df["sub_county"] = df["neighbourhood"].map(C.NEIGHBOURHOOD_TO_SUBCOUNTY)
    df = df[df["sub_county"].notna()]
    log["nairobi_monthly_unique_listings"] = int(len(df))

    out = pd.DataFrame({
        "neighbourhood": df["neighbourhood"],
        "sub_county": df["sub_county"],
        "structure": "apartment",
        "bedrooms": df["bedrooms"].astype(float),
        "bathrooms": df["bathrooms"].astype(float),
        C.TARGET: df[C.TARGET],
    }).reset_index(drop=True)
    for col in C.FEATURES:
        if col not in out:
            out[col] = np.nan  # not reported by the listing site
    return out, log


def build_dataset(save: bool = True) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    knbs, knbs_log = clean_knbs(load_knbs_rentals())
    kaggle, kaggle_log = load_kaggle()
    log = {"knbs": knbs_log, "kaggle": kaggle_log}
    if save:
        C.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
        C.REPORT_DIR.mkdir(parents=True, exist_ok=True)
        knbs.to_csv(C.PROCESSED_DIR / "nairobi_rentals_clean.csv", index=False)
        kaggle.to_csv(C.PROCESSED_DIR / "kaggle_nairobi_external.csv", index=False)
        (C.REPORT_DIR / "data_quality.json").write_text(json.dumps(log, indent=2))
    return knbs, kaggle, log
