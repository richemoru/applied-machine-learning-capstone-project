"""Stage 3-4: model selection, honest evaluation, final fit.

Evaluation design
-----------------
Listings are nested in firms (one estate agent reports many similar units), so
rows are not independent. Every split in this module is therefore grouped by
firm: a firm's listings are either all in training or all in test.

* Outer loop  - GroupKFold(5), repeated 3 times with different firm
  allocations: estimates how each tuned model performs on
  listings from firms it has never seen.
* Inner loop  - GroupKFold(4) randomised search on the outer-training part
  only: hyper-parameters never see the outer test fold (nested CV).
* Final model - the best family is re-tuned on all data and saved.
"""
from __future__ import annotations

import json
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import GroupKFold, KFold, RandomizedSearchCV, cross_val_predict

from . import config as C
from .data import clean_knbs, load_knbs_rentals
from .models import candidates

warnings.filterwarnings("ignore", message="X does not have valid feature names")


# --------------------------------------------------------------------------
# Metrics (y in KSh, predictions in KSh)
# --------------------------------------------------------------------------
def metrics(y, pred) -> dict:
    y, pred = np.asarray(y, float), np.asarray(pred, float)
    ly, lp = np.log(y), np.log(pred)
    ape = np.abs(pred - y) / y
    return {
        "MAE_KSh": float(np.mean(np.abs(pred - y))),
        "MdAE_KSh": float(np.median(np.abs(pred - y))),
        "MdAPE_pct": float(100 * np.median(ape)),
        "within_20pct_share": float(np.mean(ape <= 0.20)),
        "RMSLE": float(np.sqrt(np.mean((lp - ly) ** 2))),
        "R2_log": float(1 - np.sum((ly - lp) ** 2) / np.sum((ly - ly.mean()) ** 2)),
    }


def _search(est, space, X, ylog, groups, seed):
    if space is None:
        return clone(est).fit(X, ylog), {}
    search = RandomizedSearchCV(
        clone(est), space, n_iter=C.N_SEARCH_ITER,
        cv=GroupKFold(C.N_INNER_FOLDS), scoring="neg_mean_absolute_error",
        random_state=seed, n_jobs=-1, refit=True,
    )
    search.fit(X, ylog, groups=groups)
    return search.best_estimator_, search.best_params_


# --------------------------------------------------------------------------
# Nested grouped cross-validation
# --------------------------------------------------------------------------
def nested_cv(df: pd.DataFrame, verbose=True):
    """Repeated nested CV. Returns averaged metrics plus the out-of-fold
    predictions, fitted fold models and fold indices of the first repeat."""
    X, y, g = df[C.FEATURES], df[C.TARGET].to_numpy(), df[C.GROUP].to_numpy()
    ylog = np.log(y)
    splits = [list(GroupKFold(C.N_OUTER_FOLDS, shuffle=True,
                              random_state=C.RANDOM_STATE + r).split(X, ylog, g))
              for r in range(C.N_REPEATS)]

    oof, fold_rows, rep_rows, fold_models = {}, [], [], {}
    for name, (est, space) in candidates().items():
        for r, folds in enumerate(splits):
            pred, models = np.zeros(len(df)), []
            for k, (tr, te) in enumerate(folds):
                model, _ = _search(est, space, X.iloc[tr], ylog[tr], g[tr],
                                   C.RANDOM_STATE + 10 * r + k)
                pred[te] = np.exp(model.predict(X.iloc[te]))
                models.append(model)
                fold_rows.append({"model": name, "repeat": r, "fold": k, "n_test": len(te),
                                  **metrics(y[te], pred[te])})
            rep_rows.append({"model": name, "repeat": r, **metrics(y, pred)})
            if r == 0:
                oof[name], fold_models[name] = pred, models
        if verbose:
            m = pd.DataFrame(rep_rows).query("model == @name").mean(numeric_only=True)
            print(f"  {name:34s} MdAPE {m['MdAPE_pct']:5.1f}%  MAE {m['MAE_KSh']:>9,.0f}  "
                  f"RMSLE {m['RMSLE']:.3f}  R2(log) {m['R2_log']:.3f}", flush=True)

    per_fold = pd.DataFrame(fold_rows)
    order = list(candidates())
    summary = (pd.DataFrame(rep_rows).drop(columns="repeat").groupby("model").mean()
               .reindex(order))
    summary["RMSLE_fold_sd"] = per_fold.groupby("model")["RMSLE"].std()
    summary["MdAPE_fold_sd"] = per_fold.groupby("model")["MdAPE_pct"].std()
    return summary, per_fold, oof, fold_models, splits[0]


# --------------------------------------------------------------------------
# Grouped permutation importance on the outer test folds
# --------------------------------------------------------------------------
def group_importance(df, fold_models, folds, n_repeats=20) -> pd.DataFrame:
    """Rise in out-of-sample error when a whole feature group is shuffled.

    Groups are permuted jointly so correlated features inside a group (e.g.
    bedrooms and bathrooms) cannot stand in for each other.
    """
    X, ylog = df[C.FEATURES], np.log(df[C.TARGET].to_numpy())
    rng = np.random.default_rng(C.RANDOM_STATE)
    rows = []
    for model, (_, te) in zip(fold_models, folds):
        Xte, yte = X.iloc[te], ylog[te]
        base = np.mean(np.abs(model.predict(Xte) - yte))
        for gname, cols in C.FEATURE_GROUPS.items():
            for _ in range(n_repeats):
                Xp = Xte.copy()
                Xp[cols] = Xte[cols].to_numpy()[rng.permutation(len(Xte))]
                rows.append({"group": gname, "base": base,
                             "delta": np.mean(np.abs(model.predict(Xp) - yte)) - base})
    r = pd.DataFrame(rows)
    out = r.groupby("group").agg(delta_log_mae=("delta", "mean"), sd=("delta", "std"))
    out["baseline_log_mae"] = r["base"].mean()
    out["error_increase_pct"] = 100 * out["delta_log_mae"] / out["baseline_log_mae"]
    return out.sort_values("delta_log_mae", ascending=False)


# --------------------------------------------------------------------------
# Leakage audit: what a naive evaluation would have reported
# --------------------------------------------------------------------------
def leakage_audit(best_pipeline) -> dict:
    """Score the same tuned model under three protocols."""
    raw = load_knbs_rentals()
    res = {}
    for label, dedupe, grouped in [
        ("naive: duplicates kept, random 5-fold", False, False),
        ("duplicates removed, random 5-fold", True, False),
        ("duplicates removed, grouped by firm (reported)", True, True),
    ]:
        d, _ = clean_knbs(raw, deduplicate=dedupe)
        X, y, g = d[C.FEATURES], d[C.TARGET].to_numpy(), d[C.GROUP].to_numpy()
        cv = (GroupKFold(5, shuffle=True, random_state=C.RANDOM_STATE) if grouped
              else KFold(5, shuffle=True, random_state=C.RANDOM_STATE))
        pred = np.exp(cross_val_predict(clone(best_pipeline), X, np.log(y), cv=cv,
                                        groups=g if grouped else None))
        res[label] = {"n_rows": int(len(d)), **metrics(y, pred)}
    return res


# --------------------------------------------------------------------------
# Final fit and artifact
# --------------------------------------------------------------------------
def fit_final(df, best_name, oof_pred):
    est, space = candidates()[best_name]
    X, y, g = df[C.FEATURES], df[C.TARGET].to_numpy(), df[C.GROUP].to_numpy()
    model, params = _search(est, space, X, np.log(y), g, C.RANDOM_STATE)

    # Empirical 80% prediction band from out-of-fold log residuals.
    resid = np.log(y) - np.log(oof_pred)
    q_lo, q_hi = np.quantile(resid, [0.10, 0.90])
    artifact = {"pipeline": model, "features": C.FEATURES,
                "log_resid_q10": float(q_lo), "log_resid_q90": float(q_hi)}
    C.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifact, C.MODEL_PATH)
    clean_params = {k: (v.item() if hasattr(v, "item") else v) for k, v in params.items()}
    return artifact, clean_params


def external_check(artifact, kaggle: pd.DataFrame) -> tuple[dict, pd.DataFrame]:
    pred = np.exp(artifact["pipeline"].predict(kaggle[C.FEATURES]))
    out = kaggle[["neighbourhood", "sub_county", "bedrooms", "bathrooms", C.TARGET]].copy()
    out["predicted_ksh"] = pred.round(-2)
    out["abs_pct_error"] = (100 * (pred - out[C.TARGET]).abs() / out[C.TARGET]).round(1)
    return {"n": int(len(out)), **metrics(out[C.TARGET], pred)}, out


def write_metadata(best_name, params, summary, df, extra: dict):
    import lightgbm, sklearn, xgboost
    meta = {
        "model_family": best_name,
        "hyperparameters": params,
        "target": "advertised monthly rent, KSh (model fitted on natural log)",
        "training_rows": int(len(df)),
        "training_firms": int(df[C.GROUP].nunique()),
        "features": C.FEATURES,
        "nested_cv_metrics": summary.loc[best_name].round(4).to_dict(),
        "versions": {"scikit-learn": sklearn.__version__, "xgboost": xgboost.__version__,
                     "lightgbm": lightgbm.__version__},
        **extra,
    }
    C.METADATA_PATH.write_text(json.dumps(meta, indent=2))
    return meta
