"""Central configuration: paths, code books, feature lists.

Everything a reviewer might want to change lives here, so the rest of the
pipeline contains no magic numbers.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW_KNBS = ROOT / "data" / "raw" / "knbs_real_estate_survey.dta"
RAW_KAGGLE = ROOT / "data" / "raw" / "kaggle_apartments.csv"
PROCESSED_DIR = ROOT / "data" / "processed"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
FIG_DIR = REPORT_DIR / "figures"

MODEL_PATH = MODEL_DIR / "rent_model.joblib"
METADATA_PATH = MODEL_DIR / "model_metadata.json"

RANDOM_STATE = 42
N_OUTER_FOLDS = 5
N_REPEATS = 3          # repeats of the outer loop (different firm allocations)
N_INNER_FOLDS = 4
N_SEARCH_ITER = 20
SURVEY_YEAR = 2023  # reference year of the KNBS questionnaire ("since 1st January 2023")

# --------------------------------------------------------------------------
# KNBS code books
# --------------------------------------------------------------------------
NAIROBI_COUNTY_CODE = 47

# RB2 "Type of residential property leased/rented" -> (structure, bedrooms).
# Labels come from the value labels stored in the .dta file.
PROPERTY_TYPE = {
    1: ("bungalow", 1), 2: ("bungalow", 2), 3: ("bungalow", 3), 4: ("bungalow", 4),
    5: ("maisonette", 1), 6: ("maisonette", 2), 7: ("maisonette", 3), 8: ("maisonette", 4),
    9: ("single_room", 0), 10: ("bedsitter", 0),
    11: ("apartment", 1), 12: ("apartment", 2), 13: ("apartment", 3), 14: ("apartment", 4),
    15: ("townhouse", 1), 16: ("townhouse", 2), 17: ("townhouse", 3), 18: ("townhouse", 4),
    19: ("compound_house", 1), 20: ("compound_house", 1),
    21: ("single_room", 0), 22: ("apartment", 1), 23: ("apartment", 2),
}

# RB9 sub-county. ASSUMPTION: the .dta file ships value labels for RB9 that
# belong to another county (codes 14-18, Kitui), so the Nairobi codes 1-11 are
# unlabelled. They are mapped here to the 11 Nairobi sub-counties in the
# alphabetical order KNBS uses in the 2019 census tables. The observed median
# rents per code are consistent with this (code 11 and 6 are the dearest,
# codes 3 and 8 the cheapest) but it should be confirmed against the survey
# code book before the report is finalised.
NAIROBI_SUBCOUNTY = {
    1: "Dagoretti", 2: "Embakasi", 3: "Kamukunji", 4: "Kasarani", 5: "Kibra",
    6: "Langata", 7: "Makadara", 8: "Mathare", 9: "Njiru", 10: "Starehe",
    11: "Westlands",
}

AMENITIES = {
    "rb7__1": "cctv", "rb7__2": "elevator", "rb7__3": "garden_play_area",
    "rb7__4": "swimming_pool", "rb7__5": "backup_generator",
    "rb7__6": "fixed_internet", "rb7__7": "solar_water_heating",
    "rb7__8": "solar_lighting", "rb7__9": "gym", "rb7__10": "fire_safety",
    "rb7__11": "solar_security_lighting", "rb7__12": "access_ramp",
}

# Floor-area cleaning
AREA_PLACEHOLDER = {98.0, 99.0, 998.0, 999.0, 9998.0, 9999.0}  # "don't know" codes
SQFT_TO_SQM = 0.092903
AREA_MIN_SQM, AREA_MAX_SQM = 10.0, 1000.0

# Target cleaning (KSh per month)
RENT_MIN, RENT_MAX = 2_000, 1_000_000

# --------------------------------------------------------------------------
# Kaggle listings: neighbourhood -> sub-county (approximate, used only for the
# external sanity check, never for training).
# --------------------------------------------------------------------------
NEIGHBOURHOOD_TO_SUBCOUNTY = {
    "Kileleshwa": "Dagoretti", "Kilimani": "Dagoretti", "Lavington": "Dagoretti",
    "Hurlingham": "Dagoretti",
    "Westlands": "Westlands", "Riverside": "Westlands", "Spring Valley": "Westlands",
    "Muthaiga": "Westlands",
}

# --------------------------------------------------------------------------
# Model features
# --------------------------------------------------------------------------
TARGET = "rent_ksh"
GROUP = "firm_id"

CATEGORICAL = ["sub_county", "structure"]
BINARY = ["parking", "dsq", "service_charge_included"] + list(AMENITIES.values())
NUMERIC = ["bedrooms", "bathrooms", "floor_area_sqm", "building_age",
           "similar_units", "advert_year"]
FEATURES = CATEGORICAL + NUMERIC + BINARY

# Feature groups, aligned with the four specific objectives of the proposal.
FEATURE_GROUPS = {
    "Location (sub-county)": ["sub_county"],
    "Size (bedrooms, bathrooms, floor area)": ["bedrooms", "bathrooms", "floor_area_sqm"],
    "Building infrastructure and amenities": ["parking"] + list(AMENITIES.values()),
    "House design (structure type, DSQ, age)": ["structure", "dsq", "building_age"],
    "Listing terms (control)": ["similar_units", "advert_year", "service_charge_included"],
}

SUBCOUNTY_VALUES = sorted(NAIROBI_SUBCOUNTY.values())
STRUCTURE_VALUES = ["apartment", "bedsitter", "bungalow", "compound_house",
                    "maisonette", "single_room", "townhouse"]
