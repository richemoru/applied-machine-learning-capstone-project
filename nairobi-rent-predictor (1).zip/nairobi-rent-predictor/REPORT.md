# Predicting residential rent in Nairobi City County

DSA 8401 capstone results report. Every number below is produced by `python run_pipeline.py` and
saved under `reports/`.

## 1. Summary

- The final model predicts advertised monthly rent with a **median error of 33.6%** on listings
  from estate firms it has never seen (R² of 0.74 on log rent). A naive benchmark, the median rent
  for the same sub-county and bedroom count, scores 39.7%.
- A **support vector machine** was the best of the planned techniques. Random forest, XGBoost and
  LightGBM did not beat a regularised linear model on this data.
- **Size and building amenities** drive predictions about equally and far more than the other
  groups. Sub-county adds less than expected, because sub-county is a coarse measure of location.
- A conventional random train/test split would have reported a **19.8%** error for the same model.
  The gap to 33.6% is duplicated listings and firm-level clustering, not model skill.
- The Kaggle file could not be used for training: its 2,520 rows are 23 listings repeated.

## 2. Problem

Rent in Nairobi is set by landlords and agents with little transparent reference to comparable
units. The model gives a reference rent for a unit from its observable attributes. The proposal's
four objectives ask how location, size, infrastructure and house design influence rent; section 6
answers each with the feature group that represents it.

## 3. Data

### 3.1 KNBS real-estate survey (primary)

The file has 7,236 rows and 300 columns. It is an establishment survey of real-estate firms, and
most rows belong to other questionnaire sections (sales, commercial property, firm profile). The
residential rental roster is the usable part.

| Step | Rows |
|---|---|
| Rental roster lines (all counties) | 1,149 |
| Located in Nairobi City County | 813 |
| Removed: rent missing or outside KSh 2,000 to 1,000,000 | 46 |
| Removed: sub-county missing | 6 |
| Removed: exact duplicate of another line from the same firm | 238 |
| **Modelling table** | **523 listings, 102 firms** |

Rent ranges from KSh 4,000 to 800,000 with a median of 75,000, so the model is fitted on log rent.
Westlands supplies 246 of the 523 listings; Kamukunji, Makadara, Mathare and Njiru have six or
fewer each.

Quality issues handled in `src/rentml/data.py`:

- **Placeholder floor areas.** The value 98 is recorded as the floor area on 167 of the 813 Nairobi lines and is treated as a
  "don't know" code. Areas are converted from square feet where flagged and kept only between 10
  and 1,000 m². Floor area ends up missing for 36% of the final listings, and construction year for
  24%; both are median-imputed with a missing-value indicator.
- **Duplicates.** Firms report blocks of identical units as repeated lines.
- **Unlabelled sub-counties.** The file's value labels for the sub-county variable belong to
  another county. Codes 1 to 11 are mapped to Nairobi's 11 sub-counties in alphabetical order.
  Median rents by code fit that mapping, but it is an assumption to confirm with the code book.

### 3.2 Kaggle apartment listings (secondary)

The proposal counted 2,519 entries. After removing repeats there are **23 unique listings**, of
which 17 are monthly rentals in Nairobi neighbourhoods. Seventeen rows cannot support training or
integration, so they are held out as a small external check from a different source.

### 3.3 Leakage audit of features

Actual rent paid, revised rent and the service charge amount are excluded because they are set
together with the target. Firm identifiers are used only to form cross-validation groups.

## 4. Method

**Features (23).** Sub-county; structure type; bedrooms; bathrooms; floor area; building age;
parking; DSQ; twelve amenity flags (CCTV, elevator, garden, pool, generator, fixed internet, solar
water heating, solar lighting, gym, fire safety, solar security lighting, access ramp); number of
similar units; advert year; whether rent includes service charge.

**Evaluation.** Listings from one firm resemble each other, so all splits keep a firm's listings
together. Performance comes from nested cross-validation: five outer folds repeated three times
with different firm allocations, and inside each a four-fold randomised search of 20
configurations that never sees the outer test fold. Preprocessing sits inside the pipeline and is
refitted in every fold.

## 5. Results

| Model | Median abs. % error | Mean abs. error (KSh) | RMSLE | R² (log) |
|---|---|---|---|---|
| Median by sub-county and bedrooms (benchmark) | 39.7% | 55,900 | 0.705 | 0.613 |
| Ridge regression | 35.7% | 50,600 | 0.604 | 0.715 |
| Random forest | 35.5% | 49,900 | 0.633 | 0.688 |
| **SVM (RBF)** | **33.6%** | **47,900** | **0.583** | **0.736** |
| XGBoost | 36.9% | 51,100 | 0.652 | 0.668 |
| LightGBM | 37.8% | 51,100 | 0.649 | 0.671 |

![Model comparison](reports/figures/model_comparison.png)

How to read this:

- The SVM is best on every metric, but the margins are small next to fold-to-fold variation (the
  standard deviation of RMSLE across the 15 folds is about 0.11 for every model). It beat ridge in
  12 of 15 folds and XGBoost in 14 of 15. The ranking is consistent, not decisive.
- 30% of predictions land within 20% of the advertised rent. This is a reference-price tool, not a
  valuation.
- Model selection used the same outer folds that produce the reported score, so 33.6% is slightly
  optimistic for the chosen model.

![Predicted vs actual](reports/figures/predicted_vs_actual.png)

### 5.1 What a naive evaluation would have shown

| Protocol (same tuned SVM) | Rows | Median abs. % error |
|---|---|---|
| Duplicates kept, random 5-fold | 761 | 19.8% |
| Duplicates removed, random 5-fold | 523 | 27.8% |
| Duplicates removed, grouped by firm | 523 | 32.6% |

Duplicates let the model memorise test rows; firm clustering lets it learn each agent's price
level. Neither helps with a new landlord's unit, which is the use case.

### 5.2 External check on Kaggle listings

On the 17 Kaggle listings the median error is 23.3%, with only neighbourhood-derived sub-county,
bedrooms and bathrooms available as inputs. All 17 are mid-to-upper-market apartments in two
sub-counties, so this shows the model transfers to another source in that segment and nothing more.

## 6. Findings against the proposal objectives

Each group of features is shuffled jointly in the held-out folds; the rise in error shows how much
the model depends on it.

| Objective | Feature group | Rise in out-of-sample error |
|---|---|---|
| Infrastructure | Parking and 12 building amenities | +49% |
| Room sizes | Bedrooms, bathrooms, floor area | +49% |
| Location | Sub-county | +14% |
| House design | Structure type, DSQ, building age | +10% |
| (control) | Listing terms | +8% |

![Importance by objective](reports/figures/feature_group_importance.png)

- **Size and amenities matter most**, at about the same level.
- **Location looks weak, and that is a measurement issue.** A sub-county such as Westlands spans
  very different estates, and nearly half the sample sits in it. Amenities such as a pool, gym or
  generator also act as a proxy for neighbourhood quality, so some of the location effect is
  credited to them.
- **"Infrastructure" here means building-level infrastructure.** The survey has nothing on roads,
  transport or utilities in the area, so the proposal's third objective is only partly answered.
- These are measures of what the model uses to predict, not causal effects on rent.

## 7. Technique justification

| Technique | Decision | Reason |
|---|---|---|
| SVM (RBF) | Final model | Best nested-CV score; suits a small sample of mostly binary, standardised features |
| Ridge regression | Kept as reference | Shows how much non-linearity adds (little) |
| Random forest, XGBoost, LightGBM | Tested as planned, not selected | With 523 rows and coarse features, trees overfit firm-specific patterns |
| Log target | Used | Rent spans two orders of magnitude; errors are proportional |
| Firm-grouped nested CV | Used | Rows are clustered in firms; see section 5.1 |
| Deep learning | Excluded | 523 tabular rows |
| Merging Kaggle into training | Excluded | 17 usable rows with 3 of 23 features |
| Target encoding of firm | Excluded | Would not exist for a new landlord and leaks price level |
| SHAP | Replaced by grouped permutation importance | The objectives are about groups of correlated features, which per-feature attributions split arbitrarily |
| Drift monitoring, MLflow | Out of scope | Single cross-section, one training run |

## 8. Deployment

`api/main.py` exposes `/health`, `/model-info`, `/predict` and `/predict/batch`. Inputs are
validated with Pydantic (unknown fields, out-of-range values and non-Nairobi sub-counties are
rejected). Each prediction is returned with an 80% likely range taken from the out-of-fold
residuals. `Dockerfile` and `docker-compose.yml` package the service; see the README.

## 9. Limitations

1. **Small, uneven sample.** 523 listings, 47% in Westlands, four sub-counties with six or fewer.
   Predictions for Kamukunji, Makadara, Mathare and Njiru rest on almost no data.
2. **Advertised rents from formal agents.** The informal market, where most low-income tenants
   rent, is under-represented.
3. **Coarse location.** No ward, estate or coordinates.
4. **Sub-county labels are inferred**, as noted in 3.1.
5. **Wide uncertainty.** The 80% range for a KSh 75,000 prediction is roughly 41,000 to 153,000.
6. **Single period.** Listings are mostly from 2022 and 2023; the model has no way to track rent
   inflation.

## 10. Next steps

- Obtain ward or estate identifiers, or geocode listings, to measure location properly.
- Scrape a larger set of current listings to replace the Kaggle sample.
- Add neighbourhood infrastructure (distance to trunk roads, matatu routes, schools) to address
  the third objective fully.
