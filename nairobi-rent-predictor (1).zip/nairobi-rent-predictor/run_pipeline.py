#!/usr/bin/env python
"""End-to-end pipeline: ingest -> clean -> nested CV -> final model -> reports.

    python run_pipeline.py            # full run (about 10 minutes on 2 cores)
    python run_pipeline.py --quick    # smoke test: fewer search iterations

Outputs
    data/processed/*.csv              cleaned modelling tables
    models/rent_model.joblib          serialized model used by the API
    models/model_metadata.json        model card
    reports/*.json, *.csv, figures/   evaluation evidence
"""
import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from rentml import config as C  # noqa: E402
from rentml import plots, train  # noqa: E402
from rentml.data import build_dataset  # noqa: E402
from rentml.predict import predict_rent  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="4 search iterations instead of 20")
    args = ap.parse_args()
    if args.quick:
        C.N_SEARCH_ITER, C.N_REPEATS = 4, 1
    t0 = time.time()

    print("[1/6] Ingesting and cleaning raw data")
    df, kaggle, dq = build_dataset()
    print(json.dumps(dq, indent=2))

    print(f"[2/6] Nested firm-grouped CV ({C.N_REPEATS}x{C.N_OUTER_FOLDS} outer folds) on {len(df)} listings from "
          f"{df[C.GROUP].nunique()} firms")
    summary, per_fold, oof, fold_models, folds = train.nested_cv(df)
    C.REPORT_DIR.mkdir(exist_ok=True)
    summary.round(4).to_csv(C.REPORT_DIR / "model_comparison.csv")
    per_fold.round(4).to_csv(C.REPORT_DIR / "cv_fold_metrics.csv", index=False)

    best = summary["RMSLE"].idxmin()
    print(f"[3/6] Selected model family: {best}")
    imp = train.group_importance(df, fold_models[best], folds)
    imp.round(4).to_csv(C.REPORT_DIR / "feature_group_importance.csv")
    print(imp.round(3).to_string())

    print("[4/6] Final fit on all data")
    artifact, params = train.fit_final(df, best, oof[best])

    print("[5/6] Leakage audit and external check")
    audit = train.leakage_audit(artifact["pipeline"])
    ext_metrics, ext_rows = train.external_check(artifact, kaggle)
    ext_rows.to_csv(C.REPORT_DIR / "external_kaggle_predictions.csv", index=False)
    (C.REPORT_DIR / "leakage_audit.json").write_text(json.dumps(audit, indent=2))
    (C.REPORT_DIR / "external_check.json").write_text(json.dumps(ext_metrics, indent=2))
    for k, v in audit.items():
        print(f"  {k:48s} n={v['n_rows']:4d}  MdAPE {v['MdAPE_pct']:5.1f}%  R2(log) {v['R2_log']:.3f}")
    print(f"  Kaggle external listings (n={ext_metrics['n']}): MdAPE {ext_metrics['MdAPE_pct']:.1f}%")

    train.write_metadata(best, params, summary, df, {
        "prediction_band": "80% empirical band from out-of-fold log residuals",
        "log_resid_q10": artifact["log_resid_q10"], "log_resid_q90": artifact["log_resid_q90"],
    })

    print("[6/6] Figures and smoke prediction")
    plots.model_comparison(summary)
    plots.predicted_vs_actual(df[C.TARGET].to_numpy(), oof[best], best)
    plots.importance(imp)
    plots.leakage(audit)
    example = {"sub_county": "Westlands", "structure": "apartment", "bedrooms": 2,
               "bathrooms": 2, "floor_area_sqm": 95, "parking": 1, "elevator": 1}
    print("  example:", example, "->", predict_rent([example], artifact)[0])
    print(f"Done in {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
