# AI use disclosure

> Draft written by the AI assistant describing its own contribution. Edit it so it is accurate for
> your submission and matches the course policy before you hand it in.

**Tool:** Claude (Anthropic), used in a single session on 16 November 2026.

**What I gave it:** my approved capstone proposal, the DSA 8401 capstone brief, the KNBS real-estate
survey file and the Kaggle apartment listings file.

**What the AI produced:**

- Profiling of both datasets, including the findings that the Kaggle file holds 23 unique listings
  repeated to 2,520 rows and that the KNBS rental roster contains exact duplicate lines.
- All code in this repository: the data pipeline (`src/rentml/`), `run_pipeline.py`, the FastAPI
  service, tests, Dockerfile and docker-compose file.
- The evaluation design (nested cross-validation grouped by firm, leakage audit, grouped
  permutation importance) and the figures.
- First drafts of `README.md`, `REPORT.md` and this file.

**What the AI did not verify:**

- The Docker image build (the build environment could not reach Docker Hub). The API itself was
  run and tested outside Docker.
- The mapping of KNBS sub-county codes 1-11 to sub-county names, which is inferred.
- The mapping of Kaggle neighbourhoods to sub-counties, which is approximate.

**What I did myself:** _[fill in: problem choice and proposal, data sourcing, review and testing of
the code, running the pipeline and container, checking the assumptions above, interpretation,
presentation]_
