"""Run with `pytest -q` after `python run_pipeline.py`."""
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from api.main import app  # noqa: E402
from rentml import config as C  # noqa: E402
from rentml.data import clean_knbs, load_kaggle, load_knbs_rentals  # noqa: E402

client = TestClient(app)
BASE = {"sub_county": "Westlands", "structure": "apartment", "bedrooms": 2}


@pytest.fixture(scope="module")
def clean():
    return clean_knbs(load_knbs_rentals())[0]


def test_cleaning_rules(clean):
    assert not clean.duplicated().any()
    assert clean[C.TARGET].between(C.RENT_MIN, C.RENT_MAX).all()
    assert clean["sub_county"].isin(C.SUBCOUNTY_VALUES).all()
    assert clean["structure"].isin(C.STRUCTURE_VALUES).all()
    area = clean["floor_area_sqm"].dropna()
    assert area.between(C.AREA_MIN_SQM, C.AREA_MAX_SQM).all()


def test_no_price_derived_features():
    # leakage audit: actual rent, new rent and service charge must not be inputs
    assert not {"rb16_4", "rb18", "rb20"} & set(C.FEATURES)


def test_kaggle_is_deduplicated():
    ext, log = load_kaggle()
    assert log["unique_listings"] < log["raw_rows"] / 50
    assert len(ext) == log["nairobi_monthly_unique_listings"]


def test_health():
    assert client.get("/health").json() == {"status": "ok", "model_loaded": True}


def test_predict_minimal_payload():
    r = client.post("/predict", json=BASE)
    assert r.status_code == 200
    body = r.json()
    lo, hi = body["likely_range_ksh"]
    assert 2_000 < lo < body["predicted_rent_ksh"] < hi < 2_000_000


def test_more_bedrooms_costs_more():
    rent = [client.post("/predict", json={**BASE, "bedrooms": b, "bathrooms": b}).json()
            ["predicted_rent_ksh"] for b in (1, 2, 3)]
    assert rent == sorted(rent)


def test_batch_matches_single():
    single = client.post("/predict", json=BASE).json()
    batch = client.post("/predict/batch", json={"listings": [BASE, BASE]}).json()
    assert batch == [single, single]


@pytest.mark.parametrize("bad", [
    {**BASE, "sub_county": "Mombasa"},
    {**BASE, "bedrooms": 9},
    {**BASE, "unknown_field": 1},
    {"structure": "apartment", "bedrooms": 2},
])
def test_invalid_input_rejected(bad):
    assert client.post("/predict", json=bad).status_code == 422
