# Nairobi Rent Predictor

DSA 8401 Applied Machine Learning capstone. Predicts the advertised monthly rent (KSh) of a
residential unit in Nairobi City County from its location, size, building amenities and design,
and serves the model through a containerised FastAPI service.

| | |
|---|---|
| Primary data | KNBS real-estate survey, residential rental roster (`data/raw/knbs_real_estate_survey.dta`) |
| Secondary data | Kaggle "Apartment prices in Kenya" listings (`data/raw/kaggle_apartments.csv`), external check only |
| Modelling table | 523 unique Nairobi listings from 102 firms |
| Final model | Support vector regression (RBF kernel) on log rent |
| Honest accuracy | Median absolute percentage error 33.6% on firms the model has never seen (nested, firm-grouped CV) |

Full results, technique justification and limitations are in [`REPORT.md`](REPORT.md).

## Architecture

```mermaid
flowchart LR
    A[KNBS survey .dta] --> B[data.py<br/>ingest + clean]
    K[Kaggle listings .csv] --> B
    B --> C[nairobi_rentals_clean.csv]
    B --> X[kaggle_nairobi_external.csv]
    C --> D[train.py<br/>nested firm-grouped CV<br/>Ridge, RF, SVM, XGBoost, LightGBM]
    D --> E[rent_model.joblib<br/>model_metadata.json]
    D --> R[reports/<br/>metrics, audit, figures]
    X --> R
    E --> F[FastAPI service<br/>api/main.py]
    F --> G[Docker container :8000]
    H[Client] -- POST /predict --> G
```

## Repository layout

```
run_pipeline.py          one command: ingest -> clean -> train -> evaluate -> save
src/rentml/config.py     paths, KNBS code books, feature lists, cleaning thresholds
src/rentml/data.py       ingestion and cleaning rules (with a data-quality log)
src/rentml/models.py     preprocessing and candidate models
src/rentml/train.py      nested CV, leakage audit, grouped importance, final fit
src/rentml/plots.py      report figures
src/rentml/predict.py    prediction helper shared by CLI and API
api/main.py              FastAPI service
tests/                   pipeline and API tests
models/                  serialized model + model card (produced by the pipeline)
reports/                 metrics, audits and figures (produced by the pipeline)
Dockerfile, docker-compose.yml
```

## Reproduce from scratch

Requires Python 3.13 (the pinned library versions need it).

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python run_pipeline.py          # about 10 minutes on 2 cores
python run_pipeline.py --quick  # 1-minute smoke run with a smaller search
pytest -q                       # 11 tests: cleaning rules, leakage guard, API
```

The pipeline is seeded (`RANDOM_STATE = 42`), reads only the two files in `data/raw/`, and rewrites
everything in `data/processed/`, `models/` and `reports/`.

## Serve the model

With Docker:

```bash
docker compose up --build api
```

Without Docker:

```bash
uvicorn api.main:app --host 0.0.0.0 --port 8000
```

Then:

```bash
curl http://localhost:8000/health

curl -X POST http://localhost:8000/predict -H "Content-Type: application/json" -d '{
  "sub_county": "Westlands", "structure": "apartment", "bedrooms": 2, "bathrooms": 2,
  "floor_area_sqm": 95, "parking": 1, "elevator": 1
}'
# {"predicted_rent_ksh":74700.0,"likely_range_ksh":[41200.0,152200.0]}
```

| Endpoint | Purpose |
|---|---|
| `GET /health` | liveness and whether the model file is present |
| `GET /model-info` | model card: family, hyper-parameters, CV metrics, library versions |
| `POST /predict` | one listing in, predicted rent and 80% likely range out |
| `POST /predict/batch` | up to 500 listings |
| `GET /docs` | interactive Swagger UI |

Only `sub_county`, `structure` and `bedrooms` are required. Other fields may be omitted and are
imputed. Valid values: `sub_county` is one of Dagoretti, Embakasi, Kamukunji, Kasarani, Kibra,
Langata, Makadara, Mathare, Njiru, Starehe, Westlands; `structure` is one of apartment, bedsitter,
bungalow, compound_house, maisonette, single_room, townhouse.

To retrain inside the container: `docker compose run --rm train`.

## Data notes

- The KNBS file is a wide export of an establishment survey. Only rows on the residential rental
  roster (non-missing `rbid`) located in Nairobi (county code 47) are used.
- The sub-county labels are an assumption documented in `src/rentml/config.py`; confirm them
  against the KNBS code book.
- Check the KNBS microdata terms of use before pushing `data/raw/` to a public repository.
